export const colors = {
  black: '#000000',
  white: '#FFFFFF',
  lightGray: '#FAFAFA',
  lightGreen: '#799A82',
  darkGreen: '#10782E',
  darkGreenHover: '#295b37',
  lightBlue: '#E1F8FF',
  progressColor: '#00FF00',
  progressBarBackground: '#D9D9D9',
};
